Als erstes alle Dateien im Archiv bitte in einen normalen Ordner kopieren/entpacken und dann nur mit den entpackten Dateien interagieren!
Danach bitte folgendes durchlesen:

DisplayDayPercentage.jar sollte man niemals ausführen. Das ist das eigentliche Programm.
Falls du aus versehen versucht hast die Datei zu öffnen, empfehle ich dir den Task "Java(TM) Platform SE binary" im Task-Manager zu beenden.
(kleiner Tipp: am schnellsten öffnet man den Task-Manager mit STRG+SHIFT+ESC)

Ein Fenster bekommt man nur mit den "CLICK_ME" Dateien.
Am besten man öffnet als erstes CLICK_ME.bat um sich mit dem Programm vertraut zu machen.

!Wenn der Fortschritt nach der Konfiguration aufhört sich zu aktualisieren,
dann einfach das Fenster fokussieren und eine beliebige Taste drücken.

Fortgeschrittene Benutzer können CLICK_ME_Preset.bat mit einem beliebigen Texteditor öffnen
und dann mit nur 4 Variablen das verhalten ändern, wenn man das Preset normal öffnet.

Viel Spaß :)